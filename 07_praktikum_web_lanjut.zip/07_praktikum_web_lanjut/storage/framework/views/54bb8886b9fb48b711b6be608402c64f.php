    
    <?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-lg-12 margin-tb">
    <div class="pull-left mt-2">
    <h2>JURUSAN TEKNOLOGI INFORMASI-POLITEKNIK NEGERI MALANG</h2>
    </div>
    <div class="float-right my-2">
    <a class="btn btnsuccess" href="<?php echo e(route('users.create')); ?>"> Input Mahasiswa</a>
    </div>
    </div>
    </div>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
    <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <table class="table table-bordered">
    <tr>
    <th>Nim</th>
    <th>Nama</th>
    <th>Kelas</th>
    <th>Jurusan</th>
    <th>No_Handphone</th>
    <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>

    <td><?php echo e($Mahasiswa->Nim); ?></td>
    <td><?php echo e($Mahasiswa->Nama); ?></td>
    <td><?php echo e($Mahasiswa->Kelas); ?></td>
    <td><?php echo e($Mahasiswa->Jurusan); ?></td>
    <td><?php echo e($Mahasiswa->No_Handphone); ?></td>
    <td>
    <form action="<?php echo e(route('users.destroy',$Mahasiswa->Nim)); ?>" method="POST">

    <a class="btn btninfo" href="<?php echo e(route('users.show',$Mahasiswa->Nim)); ?>">Show</a>
    <a class="btn btnprimary" href="<?php echo e(route('users.edit',$Mahasiswa->Nim)); ?>">Edit</a>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger">Delete</button>
    </form>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravell\07_praktikum_web_lanjut\resources\views/users/index.blade.php ENDPATH**/ ?>