
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
    <div class="row justify-content-center align-items-center">
    <div class="card" style="width: 24rem;">
    <div class="card-header">
    Detail Mahasiswa
    </div>
    <div class="card-body">
    <ul class="list-group list-group-flush">
    <li class="list-group-item"><b>Nim: </b><?php echo e($Mahasiswas->Nim); ?></li>
    <li class="list-group-item"><b>Nama: </b><?php echo e($Mahasiswas->Nama); ?></li>
    <li class="list-group-item"><b>Kelas: </b><?php echo e($Mahasiswas->Kelas); ?></li>
    <li class="list-group-item"><b>Jurusan: </b><?php echo e($Mahasiswas->Jurusan); ?></li>
    <li class="list-group-item"><b>No_Handphone: </b><?php echo e($Mahasiswas->No_Handphone); ?></li>
    <li class="list-group-item"><b>E-mail: </b><?php echo e($Mahasiswas->Email); ?></li>
    <li class="list-group-item"><b>Tanggal_Lahir: </b><?php echo e($Mahasiswas->Tanggal_Lahir); ?></li>

    </ul>
    </div>
    <a class="btn btn-success mt3" href="<?php echo e(route('mahasiswas.index')); ?>">Kembali</a>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mahasiswas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravell\07_praktikum_web_lanjut\resources\views/mahasiswas/detail.blade.php ENDPATH**/ ?>